// 检查当前标签页是否为头条页面
function checkCurrentPage() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      const tab = tabs[0];
      if (tab.url && tab.url.includes('toutiao.com')) {
        document.getElementById('status').textContent = '当前页面是今日头条文章页面，可以使用提取功能';
        document.getElementById('status').style.backgroundColor = '#e8f8e8';
        document.getElementById('status').style.color = '#27ae60';
      } else {
        document.getElementById('status').textContent = '请打开今日头条文章页面使用';
        document.getElementById('status').style.backgroundColor = '#e8f4f8';
        document.getElementById('status').style.color = '#3498db';
      }
    }
  });
}

// 页面加载完成后检查当前页面
window.addEventListener('DOMContentLoaded', checkCurrentPage);